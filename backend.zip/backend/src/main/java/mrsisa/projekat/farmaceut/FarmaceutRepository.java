package mrsisa.projekat.farmaceut;

public interface FarmaceutRepository {
}
