package mrsisa.projekat.farmaceut;

public class FarmaceutController {
}
