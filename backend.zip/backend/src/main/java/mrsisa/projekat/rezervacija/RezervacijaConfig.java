package mrsisa.projekat.rezervacija;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RezervacijaConfig {
}
