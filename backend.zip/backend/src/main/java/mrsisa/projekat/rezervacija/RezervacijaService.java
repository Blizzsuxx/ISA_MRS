package mrsisa.projekat.rezervacija;

public class RezervacijaService {
}
