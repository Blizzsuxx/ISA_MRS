package mrsisa.projekat.rezervacija;

public interface RezervacijaRepository {
}
