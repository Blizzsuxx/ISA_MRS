package mrsisa.projekat.administrator;

import org.springframework.stereotype.Service;

@Service
public class AdministratorService {

}
