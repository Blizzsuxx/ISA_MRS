package mrsisa.projekat.ponuda;

public interface PonudaRepository {
}
