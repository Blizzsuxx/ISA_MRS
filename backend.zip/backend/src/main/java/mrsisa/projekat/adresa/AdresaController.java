package mrsisa.projekat.adresa;

public class AdresaController {
}
