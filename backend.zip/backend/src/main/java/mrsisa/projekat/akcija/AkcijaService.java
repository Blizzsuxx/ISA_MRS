package mrsisa.projekat.akcija;

import org.springframework.stereotype.Service;

@Service
public class AkcijaService {

}
