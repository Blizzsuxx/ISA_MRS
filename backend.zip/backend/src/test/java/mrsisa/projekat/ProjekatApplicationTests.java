package mrsisa.projekat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjekatApplicationTests {

    @Test
    void contextLoads() {
    }

}
